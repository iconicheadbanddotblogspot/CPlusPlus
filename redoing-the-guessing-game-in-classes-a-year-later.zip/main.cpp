#include <iostream>
#include <string>
#include "game.h"
using namespace std;


int main(){
  GAME yeet;
  yeet.menu();
  return 0;
}