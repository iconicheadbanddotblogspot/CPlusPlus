#ifndef GAME_H
#define GAME_H

class GAME{
  private:
     void letGame();
     void numGame();
     void numletGame();
  public:
    void menu();
};

#endif