#include <iostream>
#include <cstdlib>
#include <string>
#include "game.h"
using namespace std;

void GAME::numGame(){
  int endNum = 100;
  int startNum = 0;
  int random;
  int number;
  string name;

  cout << "what's your name?" << endl;
  cin >> name;

  random = rand() % (endNum - startNum) + startNum;

for(int i = 0; i <= 4; i++){
    cout <<  name << ", enter a number between 0 & 100." << endl;
    cin >> number;
    if (number < random){
    cout << name << ", that isn't the right number, go higher." << endl;
  } else if (number > random){
    cout << name << ", that isn't the right number, go lower." << endl;
  } else {
  if (number == random){
    cout << name << ", that's the right number! you win!" << endl;
    break;
    } else if (number < 0 || number > 100){
      cout << "invalid input" << endl;
     }
   }
  }
cout << name << ", the correct number was " << random << "." << endl;
cout << "Play another game, or replay this one, or just don't." << endl;
cout << "press 1 for the Number Guessing Game & 2 for the Letter Guessing Game"<< endl;
cout << "or 3 to quit." << endl;
}

void GAME::letGame(){
  char input;
    string name;
    int n = rand() % 26;
    char random = (char)(n + 97);

    cout << "what's your name?" << endl;
    cin >> name;
    //cout << random;

    for(int j = 0; j <= 4; j++){
    cout << name << ", enter a lowercase letter." << endl;
    cin >> input;
    if(input < 97 && input > 122){
      cout << "Follow directions, bitch face." << endl;
    }
    if(input < random){
      cout << name << " that isn't the right letter, go higher." << endl;
    } else if (input > random){
      cout << name << ", that isn't the right letter, go lower." << endl;
    }
      else{
        if(input == random){
          cout << name << ", that's the right letter!" << endl;
          break;
        }
      }
    }
    cout << name << ", the correct letter was " << random << "." << endl;
    cout << "Play another game, or replay this one, or just don't." << endl;
    cout << "press 1 for the Number Guessing Game & 2 for the Letter Guessing Game"<< endl;
    cout << "or 3 to quit." << endl;
  }

  void GAME::numletGame(){
    char input;
    string name;
    int endNum = 100;
    int startNum = 0;
    int random = rand() % (endNum - startNum) + startNum;
    int number;
    int n = rand() % 26;
    char randomer = (char)(n + 97);

  for(int i = 0; i <= 4; i++){
    cout <<  name << ", enter a number between 0 & 100." << endl;
    cin >> number;
    cout << name << ", enter a letter between a & z." << endl;
    if (number < random && input < randomer){
    cout << name << ", that isn't the right number or letter, go higher on both." << endl;
  } else if (number > random && input > randomer){
    cout << name << ", that isn't the right number or letter, go lower on both." << endl;
  } else if (number == random && input < randomer){
    cout << name << ", that's the right number, but wrong letter. go higher." << endl;
  } else if (number == random && input > randomer){
    cout << name << ", that's the right number, but wrong letter. go lower." << endl;
  } else if (number < random && input == randomer){
    cout << name << ", that's the right letter, but wrong number. go higher." << endl;
  } else if (number > random && input == randomer){
    cout << name << ", that's the right letter, but wrong number. go higher." << endl;
  } else if (number < random && input < randomer){
    cout << name << ", that isn't the right number or letter, go higher on both." << endl;
  } else if (number < 0 || number > 100){
      cout << "invalid input" << endl;
     } else if (input < 'a' || input > 'z'){
       cout << "invalid output" << endl;
     }
   }
cout << name << ", the correct number was " << random << "." << endl;
cout << "Play another game, or replay this one, or just don't." << endl;
cout << "press 1 for the Number Guessing Game & 2 for the Letter Guessing Game"<< endl;
cout << "or 3 to quit." << endl;
}

void GAME::menu(){

  int answer;
  

  cout << "-----------------------------------------" << endl; 
  cout << "(1) Number Guessing Game" << endl;
  cout << "(2) Letter Guessing Game" << endl;
  cout << "(3) Number & Letter Game" << endl; 
  cout << "(4) Quit" << endl;
  cout << "-----------------------------------------" << endl;

  do{
  cin >> answer;
 switch(answer){
   case 1:{
    cout << "lets play!" << endl;
    numGame();
    break;
  }
  case 2:{
    cout << "let's play!" << endl;
    letGame();
    break;
  }
  case 3:{
    cout << "let's play!" << endl;
    numletGame();
    break;
  }
  case 4:{
      break;
			default:
				cout << "goodbye" << endl;
   }
  }
 } while (answer != '4');
}